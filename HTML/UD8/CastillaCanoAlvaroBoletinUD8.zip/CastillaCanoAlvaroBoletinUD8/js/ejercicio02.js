let mensaje = "Hola que tal";

alert(mensaje);