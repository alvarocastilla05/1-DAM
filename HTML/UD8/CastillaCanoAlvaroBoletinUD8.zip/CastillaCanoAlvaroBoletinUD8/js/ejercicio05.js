let num1 = 5;
let num2 = 8;

if(num1<num2){
    alert("numero1 no es mayor que numero2")
}
if(num2>=0){
    alert("numero2 es positivo")
}
if(num1!=0){
    alert("numero1 es negativo o distinto de 0")
}
if(num1+1!=num2){
    alert("incrementar en 1 unidad el valor de numero1 no lo hace mayor o igual que numero2")
}