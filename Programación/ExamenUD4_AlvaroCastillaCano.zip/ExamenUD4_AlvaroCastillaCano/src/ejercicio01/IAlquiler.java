package ejercicio01;

public interface IAlquiler {

	public double calcularPrecio(double fijoBatmovil);
}
