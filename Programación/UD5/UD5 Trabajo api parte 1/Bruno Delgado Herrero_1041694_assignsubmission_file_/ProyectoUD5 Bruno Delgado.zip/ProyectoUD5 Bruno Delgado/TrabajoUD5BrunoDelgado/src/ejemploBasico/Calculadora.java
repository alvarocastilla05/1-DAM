package ejemploBasico;

public class Calculadora implements IOperaciones  {

	public Calculadora() {
		
	}
	
}
