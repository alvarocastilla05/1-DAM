package ejemploSuperHeroes;

public class Superman implements ISuperPoderes {

}
