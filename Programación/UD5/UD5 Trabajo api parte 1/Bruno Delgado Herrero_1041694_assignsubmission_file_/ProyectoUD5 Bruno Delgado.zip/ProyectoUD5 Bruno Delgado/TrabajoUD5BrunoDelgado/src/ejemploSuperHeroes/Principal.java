package ejemploSuperHeroes;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IronMan im = new IronMan();
		
		Superman sm = new Superman();
		
		im.volar();
		
		sm.volar();
	}

}
