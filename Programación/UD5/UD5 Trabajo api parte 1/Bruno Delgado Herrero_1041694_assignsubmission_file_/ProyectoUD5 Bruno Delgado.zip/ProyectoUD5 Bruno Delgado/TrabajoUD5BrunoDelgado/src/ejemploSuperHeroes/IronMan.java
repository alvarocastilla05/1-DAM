package ejemploSuperHeroes;

public class IronMan implements ISuperPoderes {

}
