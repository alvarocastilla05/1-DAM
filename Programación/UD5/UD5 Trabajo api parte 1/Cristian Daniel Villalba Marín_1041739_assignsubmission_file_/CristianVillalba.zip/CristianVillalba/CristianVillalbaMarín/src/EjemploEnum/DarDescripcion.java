package EjemploEnum;

public interface DarDescripcion {
	String getDescripcion();
}
