Hay metodos incompletos y la documentacion no es correcta 
ya que es la primera version