package ejemploList;

public class Alumno {

	/*En el ejemplo que veremos tendremos una gestion de alumnos de una escuela.
	 * En primer lugar creamos la clase alumno
	 * Los atributos como veis son: 
	 * -Un id para gestionarlos mejor
	 * -Un nombre y un apellido como todo el mundo tiene
	 * -Un curso para saber en que curso están*/
	
	//Atributos
	
	private int idAlumno;
	private String nombre;
	private String apellido;
	private String curso;
	
	/*Creamos constructores, getters and setters y un toString dentro de la clase,
	 * que utilizaremos más tarde.*/
	
	//Constructores
	
	public Alumno(int idAlumno, String nombre, String apellido, String curso) {
		super();
		this.idAlumno = idAlumno;
		this.nombre = nombre;
		this.apellido = apellido;
		this.curso = curso;
	}

	//Getters and setters
	
	public int getIdAlumno() {
		return idAlumno;
	}


	public void setIdAlumno(int idAlumno) {
		this.idAlumno = idAlumno;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public String getCurso() {
		return curso;
	}


	public void setCurso(String curso) {
		this.curso = curso;
	}

	//To String
	
	@Override
	public String toString() {
		return "Alumno [idAlumno=" + idAlumno + ", nombre=" + nombre + ", apellido=" + apellido + ", curso=" + curso
				+ "]";
	}
	
	
	
	
}
