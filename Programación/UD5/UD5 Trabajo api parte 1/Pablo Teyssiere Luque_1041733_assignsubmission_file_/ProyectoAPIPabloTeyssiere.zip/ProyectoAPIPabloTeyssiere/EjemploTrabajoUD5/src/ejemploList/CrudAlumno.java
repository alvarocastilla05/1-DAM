package ejemploList;

import java.util.List;

public class CrudAlumno {

	/*Dentro de esta clase gestionaremos los principales métodos
	 * (llamados métodos CRUD)de la clase alumno.
	 * 
	 * Empezamos creando una lista de alumno, que será List,
	 * donde posteriormente añadiremos los alumnos.
	 * Tendremos que importar la interfaz list una vez 
	 * creemos el atributo.
	 * 
	 * Y creamos constructores y getters and setters*/
	
	//Atributos
	
	private List <Alumno> lista;

	//Constructores
	
	public CrudAlumno(List<Alumno> lista) {
		super();
		this.lista = lista;
	}

	//Getters and setters
	
	public List<Alumno> getLista() {
		return lista;
	}

	public void setLista(List<Alumno> lista) {
		this.lista = lista;
	}
	
	//Apartir de aquí empezamos con la creación de métodos
	
	//Métodos
	
	/*Primer método, añadir, donde añadiremos los alumnos
	 * a la lista que hemos creado.
	 * Para ello utilizaremos el método de la interfaz list,
	 * dentro de collections, que sirve para añadir a la lista*/
	
	
	public void añadir (Alumno a) {
		lista.add(a);
	}
	
	//Este método solo sirve para mostrar todos los elementos
	//que contiene la lista.
	
	public void mostrar () {
		for (Alumno a : lista) {
			System.out.println(a);
		}
	}
	
	/*Tercer método que creamos que nos sirve para buscar
	 * un alumno por el id de ese alumno.
	 * Utilizamos el método lista.size y lista.get 
	 * que nos incluye la interfaz list.
	 * lista.size nos devuelve el tamaño de la lista
	 * lista.get nos devuelve el alumno en una determinada posición*/
	
	
	public Alumno buscarPorId (int idAlumno) {
		
		int i=0;
		boolean encontrado=false;
		
		while (i<lista.size()&& !encontrado) {
			if((lista.get(i)).getIdAlumno()==idAlumno) {
				encontrado=true;
				
			}else {
				i++;
			}
			
		}
		
		if(encontrado)
			return lista.get(i);
		else
			return null;
		
	}
	
	//Creamos un método parecido al anterior pero
	//que nos devuelve un boolean para comprobar
	//si el id introducido por el usuario es válido
	//o no lo es.
	
	public boolean buscarPorIdV2 (int idAlumno) {
		
		int i=0;
		boolean encontrado=false;
		
		while (i<lista.size()&& !encontrado) {
			if((lista.get(i)).getIdAlumno()==idAlumno) {
				encontrado=true;
				
			}else {
				i++;
			}
			
		}
		
		return encontrado;
	}
	
	/*Otro método, borrar, como bien el propio nombre
	 * indica, sirve para borrar un alumno de la lista.
	 * Aqui utilizamos el método lista.remove de la interfaz
	 * list importada anteriormente.
	 * lista.remove borra un elemento de la lista, indicando 
	 * anteriormente el elemento que queremos borrar
	 * 
	 * Está unido con el método buscar para que borre el 
	 * alumno que nosotros hemos querido*/
	
	public void borrar (int idAlumno) {
		lista.remove(buscarPorId(idAlumno));
	}
	
	//Este método solo modifica el curso de un alumno
	
	public void modificarCurso (int idAlumno, String nuevoCurso) {
		Alumno a=buscarPorId(idAlumno);
		a.setCurso(nuevoCurso);
	}
	
	/*Otro método, borrar, como bien el propio nombre
	 * indica, sirve para borrar todos los alumnos de la lista.
	 * Aqui utilizamos el método lista.clear de la interfaz
	 * list importada anteriormente.
	 * lista.clear borra todos los elementos de la lista
	 * indicada.*/
	
	public void borrarTodosAlumnos () {
		lista.clear();
	}
	
}
