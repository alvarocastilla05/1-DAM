package ejemploList;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ppal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//TRABAJO COLLECTIONS, PABLO TEYSSIERE LUQUE 1ºDAM
		
		/*Esta parte solo sirve para probar todo, puede probar 
		 * todas las opciones(existentes dentro del menu) 
		 * con completa libertad.
		 * 
		 * En la opciones se añaden los métodos se han creado con 
		 * antelación.
		 * Tambien se ha creado un objeto clase List, instanciado
		 * como ArrayList.*/
		
		List <Alumno> lista= new ArrayList <Alumno> ();
		CrudAlumno crA= new CrudAlumno (lista);
		
		Scanner sc=new Scanner (System.in);
		
		int idAlumno, op;
		String nombre, apellido, curso, aux;
		
		Alumno a1 = new Alumno (1, "Pablo", "Teyssiere", "1ºDam");
		Alumno a2 = new Alumno (2, "Antonio", "Sánchez", "1ºAIF");
		Alumno a3 = new Alumno (3, "Valeria", "Martínez", "1ºComercio");
		Alumno a4 = new Alumno (4, "Pedro", "Sánchez","1ºDam");
		
		crA.añadir(a1);
		crA.añadir(a2);
		crA.añadir(a3);
		crA.añadir(a4);
		
		
		System.out.println("----------------Bienvenido-------------------");
		do {
			
		
		System.out.println("""
				---------------------------------------------
				Menu:
				---------------------------------------------
				Pulse el número para realizar estas opciones.
				0.Para salir
				1.Para añadir nuevo alumno
				2.Para eliminar un alumno
				3.Para buscar los datos de un alumno
				4.Para modificar el curso de un alumno
				5.Para mostrar todos los alumnos
				6.Para borrar todos los alumnos
				----------------------------------------------
				""");
		aux=sc.nextLine();
		op=Integer.parseInt(aux);
		
		switch (op) {
		case 0:
			System.out.println("Saliendo...");
			break;			
		case 1:
			
			Alumno a;
			System.out.println("Introduce el id del alumno");
			aux=sc.nextLine();
			idAlumno=Integer.parseInt(aux);
			System.out.println("Introduce el nombre del alumno");
			nombre=sc.nextLine();
			System.out.println("Introduce el apellido del alumno");
			apellido=sc.nextLine();
			System.out.println("Introduce el curso del alumno");
			curso=sc.nextLine();
			
			a=new Alumno (idAlumno,nombre, apellido, curso);
			crA.añadir(a);
			break;
		case 2:
			System.out.println("indique la id del alumno que desea borrar");
			aux=sc.nextLine();
			idAlumno=Integer.parseInt(aux);
			
			if(crA.buscarPorIdV2(idAlumno)) {
				crA.borrar(idAlumno);
				System.out.println("Se ha borrado con éxito el alumno con id="+idAlumno);
			}else
				System.out.println("Alumno no encontrado");
			
			break;
		case 3:
			System.out.println("indique la id del alumno que desesa buscar");
			aux=sc.nextLine();
			idAlumno=Integer.parseInt(aux);
			
			if(crA.buscarPorIdV2(idAlumno)) 
				System.out.println(crA.buscarPorId(idAlumno));
			else
				System.out.println("Alumno no encontrado");	
			
			break;
		case 4:
			System.out.println("indique la id del alumno que desesa modificar el curso");
			aux=sc.nextLine();
			idAlumno=Integer.parseInt(aux);

			if(crA.buscarPorIdV2(idAlumno)) {
			System.out.println(crA.buscarPorId(idAlumno));
			
			System.out.println("Indique el curso al que quiere cambiar el alumno");
			curso=sc.nextLine();
			
			crA.modificarCurso(idAlumno, curso);
			System.out.println(crA.buscarPorId(idAlumno));
			
			}else
				System.out.println("Alumno no encontrado");
			
			break;
		case 5:
			crA.mostrar();
			break;
		
		case 6:
			System.out.println("Se van a borrar todos los alumnos de la lista.");
			System.out.println("¿Está seguro que quiere hacerlo?");
			System.out.println("""
					Pulse 1 si está seguro
					Pulse 2 si desea no hacerlo
					""");
			aux=sc.nextLine();
			op=Integer.parseInt(aux);
			
			switch (op) {
			case 1:
				crA.borrarTodosAlumnos();
				System.out.println("Se han borrado todos los alumnos satisfactoriamente");
				break;
			case 2:
				System.out.println("No se realizó la operación");
				break;
			default:
				System.out.println("SOLO ERA PULSAR 1 O 2, NO ES TÁN DIFICIL");
				break;
			}
			break;
		default:
			System.out.println("Valor no válido, vuelve a probar");
			break;
		}
		
		
	}while (op!=0);
	}
}
