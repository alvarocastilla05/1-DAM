package proyectoDeQue;

import java.util.Deque;
import java.util.LinkedList;

	
										/*
										  
										El colegio Salesianos de Triana está implementando un nuevo sistema de gestión de colas
										para sus alumnos en la oficina de administración. Han contratado a un equipo de
										desarrolladores para crear un programa que permita a los administradores realizar varias
										operaciones de gestión de colas.
										
										El programa debe permitir a los administradores:
										Agregar Alumnos a la Cola:
										● Los administradores pueden agregar alumnos a la cola de dos maneras: al
										principio o al final.
										● Cuando se agrega un alumno, se solicita su nombre, apellidos, edad, código
										de alumno y número de teléfono.
										Mostrar Alumnos en la Cola:
										● Los administradores pueden ver la información de los alumnos en la cola.
										● Tienen la opción de mostrar únicamente al primer alumno, todos los alumnos
										en la cola o solamente al último alumno.
										Eliminar Alumnos de la Cola:
										● Los administradores pueden eliminar al último alumno de la cola.
										● También tienen la opción de eliminar a un alumno específico ingresando su
										código de alumno.
										
										El sistema debe proporcionar un menú interactivo que permita a los administradores realizar
										estas operaciones de manera intuitiva.
										Utiliza la clase Alumno proporcionada y la clase CrudAlumno para manejar las operaciones
										relacionadas con la cola de alumnos.
										 */

public class Principal {
	public static void main(String[] args) {
		Deque<Alumno> lista = new LinkedList<>();
		int boton1;
		int boton2;
		int boton3;
		int cero = 0;
		String nombre;
		String apellidos;
		int edad;
		String codAlumno;
		String telefono;

		CrudAlumno c = new CrudAlumno(lista);
		System.out.println("Bienvenidos al programa de la gestión de una cola de alumnos");
		System.out.println("");

		do {
			System.out.println("""
					Por favor, pulse:
					
					->0. Para salir del menú
					->1. Para añadir a un alumno a la cola
					->2. Para mostrar los alumnos añadidos a la cola
					->3. Para eliminar el ultimo elemento de la cola
					->4. Para eliminar a un alumno por su codigo de alumno
					""");

			boton1 = Leer.datoInt();
			switch (boton1) {
			case 1:
				System.out.println("""
						Ha elegido la opción de añadir a un alumno, por favor, pulse:


						->1. Si quiere añadirlo al comienzo de la cola
						->2. Si quiere añadirlo al final de la cola

						""");
				boton2 = Leer.datoInt();

				switch (boton2) {

				case 0:
					System.out.println("Saliendo del programa");
					break;
				
				// anhade al alumno al principio de la cola
				case 1:
					System.out.println("Indique el nombre del alumno");
					nombre = Leer.dato();
					System.out.println("Sus apellidos también");
					apellidos = Leer.dato();
					System.out.println("Ahora su edad");
					edad = Leer.datoInt();
					System.out.println("¿Cuál es su código de alumno?");
					codAlumno = Leer.dato();
					System.out.println("Y para terminar, su número de teléfono por favor");
					telefono = Leer.dato();

					c.anhadirInicioCola(new Alumno(nombre, apellidos, edad, codAlumno, telefono));

					break;

				// anhade al alumno al final de la cola
				case 2:
					System.out.println("Indique el nombre del alumno");
					nombre = Leer.dato();
					System.out.println("Sus apellidos también");
					apellidos = Leer.dato();
					System.out.println("Ahora su edad");
					edad = Leer.datoInt();
					System.out.println("¿Cuál es su código de alumno?");
					codAlumno = Leer.dato();
					System.out.println("Y para terminar, su número de teléfono por favor");
					telefono = Leer.dato();

					c.anhadirFinalCola(new Alumno(nombre, apellidos, edad, codAlumno, telefono));
					break;
				}
				break;

			case 2:
				System.out.println(
						"""
								Le podemos proporcionar tres maneras diferentes de mostrarle los alumnos añadidos y para ello deber pulsar:

								->1. Para mostrar únicamente al primer alumno de la cola
								->2. Para mostrar la lista de alumnos completas
								->3. Para mostrar únicamente al último alumno de la cola
								""");
				boton3 = Leer.datoInt();

				switch (boton3) {
				case 1:

					// muestra el primer elemento anhadido a la cola
					c.mostrarPrimerElementoCola();
					break;
				case 2:

					// muestra todos los elementos de la cola
					c.mostrarElementosCola();
					break;
				case 3:

					// muestra el ultimo elemento de la cola
					c.mostrarUltimoElementoCola();
					break;
				}
				break;

			case 3:
				// de la cola, elimina al ultimo elemento que haya en ella
				c.eleminarUltimoElementoCola();

				break;

			case 4:
				// pedimos codigo del alumno, y borramos al alumno que tenga ese codigo
				System.out.println("Por favor, introduzca el dni del alumno que quiere eliminar del sistema");
				c.borrarAlumno(Leer.dato());
				break;
				
			default:
				System.out.println("Opción no válida");
				break;
			}

		} while (boton1 != cero);
	}
}