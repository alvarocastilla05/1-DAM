package proyectoQueue;

import java.util.LinkedList;
import java.util.Queue;


											/*
				La agencia de talentos "Agencias Roman" está implementando un sistema para gestionar a
				sus clientes Famosos, que incluyen Futbolistas, Influencers y Streamers.
				
				
				Se requiere un programa que permita agregar nuevos famosos a la agencia, mostrar la lista
				de todos los famosos registrados, mostrar el primer famoso en la cola de la agencia, borrar
				un famoso una vez que ha sido atendido y eliminar un famoso buscándolo por su número de
				identificación (DNI).
				
				
				La agencia tiene diferentes tipos de famosos, cada uno con atributos específicos:
				Futbolista: Tiene un sueldo fijo, nombre, DNI, número de teléfono de contacto,
				usuario en redes sociales y la cantidad de goles que metió en la temporada pasada.
				Influencer: Tiene un sueldo fijo, nombre, DNI, número de teléfono de contacto,
				usuario en redes sociales y la cantidad de seguidores que tiene.
				Streamer: Tiene un sueldo fijo, nombre, DNI, número de teléfono de contacto,
				usuario en redes sociales, la cantidad de seguidores y la media de visualizaciones
				por stream.
				
				
				El programa debe permitir al usuario realizar las siguientes acciones:
				Agregar un famoso a la agencia seleccionando el tipo de famoso entre futbolista,
				influencer o streamer, y proporcionando los detalles correspondientes (sueldo fijo,
				nombre, DNI, teléfono de contacto, usuario en redes sociales y detalles específicos
				según el tipo de famoso).
				
				
				Mostrar la lista de todos los famosos registrados en la agencia, incluyendo su tipo y
				detalles específicos.
				
				
				Mostrar al primer famoso en la cola de la agencia.
				Borrar un famoso de la cola una vez que ha sido atendido.
				Eliminar a un famoso buscándolo por su número de identificación (DNI).
											
											*/


public class Principal {
    public static void main(String[] args) {
        Queue <Famoso> lista = new LinkedList <>();
        int boton;
		int boton2;
        int cero = 0;
        double sueldoFijo;
		String nombreFamoso;
		String dni;
		String telefonoContactoFamoso;
		String redesSocialesFamoso;
		int numeroDeSeguidores;
		double mediaVisualizaciones;
		int cantidadGoles;

		

       
        String nombreAgencia= "Agencias Roman";
        
        AgenciaFamoso a = new AgenciaFamoso(lista, "Agencias Roman");
       



		System.out.println("");
       
        
        System.out.println("Bienvenidos a la inscripcion para pertenecer a la companhia de famosos"+nombreAgencia);
        System.out.println("");
        
        do {
        	
        	System.out.println("""
        			Por favor, pulse:
        			
        			0.Para salir del menú
        			1.Para agregar un famoso
        			2.Para mostrar los famososo de la agencia
        			3.Para mostrar el primer cliente de la cola
        			4.Para borrar al famoso una vez atendido
        			5.Para eliminar a un famoso buscando por dni
					
					
        			""");
        	boton=Leer.datoInt();
        	
        	switch(boton) {
        	
	        	case 0:
	        		System.out.println("Saliendo del programa");
	        		break;
	        	
	        	case 1:
	
					System.out.println("Por favor, pulse 1 si su famoso es un futbolista, 2 si es influencer , 3 si es streamer");
					boton2=Leer.datoInt();
	
					
					switch (boton2) {
						case 1:
						System.out.println("Por favor, introduzca el sueldo fijo que va a tener el Famoso que se va a unir a la Agencia");
						sueldoFijo=Leer.datoDouble();
						System.out.println("¿Cuál es el nombre del titular?");
						nombreFamoso=Leer.dato();
						System.out.println("¿Cúal es su dni?");
						dni=Leer.dato();
						System.out.println("Ponga el numero de telefono  del futbolista para poder ponernos en contacto con su persona");
						telefonoContactoFamoso=Leer.dato();
						System.out.println("Introduzca el usuario en redes sociales del famoso");
						redesSocialesFamoso=Leer.dato();
						System.out.println("¿Cuántos goles metio la temporada pasada?");
						cantidadGoles=Leer.datoInt();
						a.addFamosoALaCola(new Futbolista(sueldoFijo, nombreFamoso, dni, telefonoContactoFamoso, redesSocialesFamoso,cantidadGoles));
	
					
							break;
	
							case 2:
						System.out.println("Por favor, introduzca el sueldo fijo que va a tener el Famoso que se va a unir a la Agencia");
						sueldoFijo=Leer.datoDouble();
						System.out.println("¿Cuál es el nombre del titular?");
						nombreFamoso=Leer.dato();
						System.out.println("¿Cúal es su dni?");
						dni=Leer.dato();
						System.out.println("Ponga el numero de telefono de el/la influencer para poder ponernos en contacto con su persona");
						telefonoContactoFamoso=Leer.dato();
						System.out.println("Introduzca el usuario en redes sociales del famoso");
						redesSocialesFamoso=Leer.dato();
						System.out.println("Introduzca la cantidad de seguidores que tiene el/la influencer");
						numeroDeSeguidores=Leer.datoInt();
						a.addFamosoALaCola(new Influencer(sueldoFijo, nombreFamoso, dni, telefonoContactoFamoso, redesSocialesFamoso, numeroDeSeguidores));
						break;
	
						
	
	
						case 3:
						System.out.println("Por favor, introduzca el sueldo fijo que va a tener el Famoso que se va a unir a la Agencia");
						sueldoFijo=Leer.datoDouble();
						System.out.println("¿Cuál es el nombre del titular?");
						nombreFamoso=Leer.dato();
						System.out.println("¿Cúal es su dni?");
						dni=Leer.dato();
						System.out.println("Ponga el numero de telefono de el/la streamer para poder ponernos en contacto con su persona");
						telefonoContactoFamoso=Leer.dato();
						System.out.println("Introduzca el usuario en redes sociales del famoso");
						redesSocialesFamoso=Leer.dato();
						System.out.println("¿Y cuántos seguidores?");
						numeroDeSeguidores=Leer.datoInt();
						System.out.println("¿Cuál es la media de visualizaciones por stream del famoso?");
						mediaVisualizaciones=Leer.datoDouble();
						a.addFamosoALaCola(new Streamer(sueldoFijo, nombreFamoso, dni, telefonoContactoFamoso, redesSocialesFamoso,mediaVisualizaciones, numeroDeSeguidores));
						break;
						
						default:
							System.out.println("Opción incorrecta");
							break;
					}
	
	        	break;
	        	case 2:
	        		
	        		
	        		System.out.println("Lista de todos los Famosos");
					//mostrar todos los famosos anhadidos
	        		a.mostrarFilaDeFamosos();
	        		break;
	        		
	        	case 3:
	        		//muestra unicamente al primer famoso de la agencia
	        		
	        		
	        		System.out.println("El primero famoso de la agencia anhadido es: ");
	        		a.mostrarPrimerClienteDeLaAgencia();
	        		break;
	        		
	        	case 4:
	        		//una vez atendido al famoso, pulsando este boton se borrara
	        		a.borrarFamosoDeLaColaAtendido();
	        		break;
	
					case 5:
					//pedimos el dni del famoso para buscarlo y lo eliminamos
					System.out.println("Introduzca el dni del Famoso que quiere eliminar de la cola");
					a.borrarClienteSolicitado(Leer.dato());

					break;
	
					default:
					System.out.println("Opcion inconrrecta");
					break;
					
	        	}
	
				
        	
        }while (boton!=cero);
      
        
       
        
    }
}
