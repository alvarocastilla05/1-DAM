package EjemploAleatorios;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CRUDAlumno {

	 private List<Alumno> listaAlumnos = new ArrayList<>();
	 private Random random = new Random();

	    public CRUDAlumno(List<Alumno> listaAlumnos) {
		super();
		this.listaAlumnos = listaAlumnos;
	    }
	    
		public List<Alumno> getListaAlumnos() {
			return listaAlumnos;
		}


		public void setListaAlumnos(List<Alumno> listaAlumnos) {
			this.listaAlumnos = listaAlumnos;
		}


		
		public void agregarAlumno(Alumno alumno) {
	        listaAlumnos.add(alumno);
	    }

	    public Alumno buscarAlumnoPorDNI(String dni) {
	        for (Alumno alumno : listaAlumnos) {
	            if (alumno.getDni().equals(dni)) {
	                return alumno;
	            }
	        }
	        return null;
	    }

	    public void eliminarAlumno(String dni) {
	        Alumno alumno = buscarAlumnoPorDNI(dni);
	        if (alumno != null) {
	            listaAlumnos.remove(alumno);
	        }
	    }

	    public void mostrarListaAlumnos() {
	        for (Alumno alumno : listaAlumnos) {
	            System.out.println(alumno);
	        }
	    }	

	    public void seleccionarNotasMediasAleatorias() {
	        for (Alumno alumno : listaAlumnos) {
	            alumno.setNotaMedia(random.nextDouble() * 10); 
	        }
	    }

	    public Alumno realizarSorteo() {
	        int indiceGanador = random.nextInt(listaAlumnos.size());
	        return listaAlumnos.get(indiceGanador);
	    }
	

	    
}
