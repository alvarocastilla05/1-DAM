package EjemploAleatorios;

import java.util.ArrayList;
import java.util.List;

import utilidades.Leer;

public class Principal {

	/*Realiza un programa que permita hacer un sorteo entre todos los alumnos de Primero DAM. 
	Para ello usaremos la clase ArrayList donde se deben guardar objetos tipo Alumno con los atributos; Nombre, 
	Apellidos, Edad, DNI y Nota media, el programa tendrá que tener varias opciones como: Agregar alumno, buscar
	alumno por DNI, eliminar alumno, mostrar lista de alumnos, seleccionar notas medias aleatorias y hacer el sorteo.  
	 */
	
	public static void main(String[] args) {
	
	List <Alumno> lista = new ArrayList<>();
	CRUDAlumno crudAlumno = new CRUDAlumno(lista);
	int op =0;
	int edad;
	double notaMedia;
	String nombre,apellidos,dni;
	
	
	do {
	            System.out.println("\nMenú:");
	            System.out.println("1. Agregar alumno");
	            System.out.println("2. Buscar alumno por DNI");
	            System.out.println("3. Eliminar alumno");
	            System.out.println("4. Mostrar lista de alumnos");
	            System.out.println("5. Sorteo");
	            System.out.println("6. Notas Aleatorias");
	            System.out.print("Elige una opción: ");
	            
	            op=Leer.datoInt();

	            switch (op) {
	                case 1:
	                	
	                    System.out.println("Diga el nombre: ");
	                    nombre = Leer.dato();
	                    System.out.println("Diga los apellidos: ");
	                    apellidos=Leer.dato();
	                    System.out.println("Diga la edad: ");
	                    edad= Leer.datoInt();
	                    System.out.println("Diga el DNI: ");
	                    dni = Leer.dato();
	                    System.out.println("Diga su nota media");
	                    notaMedia=Leer.datoDouble();
	                    crudAlumno.agregarAlumno(new Alumno(nombre,apellidos,edad,dni,notaMedia));
	                    break;
	                case 2:
	                    System.out.println("Introduce el DNI del alumno: ");
	                    dni = Leer.dato();
	                     break;
	                case 3:
	                    System.out.println("Introduce el DNI del alumno a eliminar: ");
	                    dni= Leer.dato();
	                     break;
	                case 4:
	                    System.out.println("Lista de alumnos:");
	                    crudAlumno.mostrarListaAlumnos();
	                    break;
	                case 5:
	                     System.out.println("Generando Sorteo . . .");
	                     System.out.println(crudAlumno.realizarSorteo());
	                    
	                     break;
	                case 6: 
	                	System.out.println("Generando notas aleatorias . . .");
	                	crudAlumno.seleccionarNotasMediasAleatorias();
	                	break;
	                default:
	                    System.out.println("Opción no válida.");
	            } 
					
			} while (op!=0);
	
	}
}
