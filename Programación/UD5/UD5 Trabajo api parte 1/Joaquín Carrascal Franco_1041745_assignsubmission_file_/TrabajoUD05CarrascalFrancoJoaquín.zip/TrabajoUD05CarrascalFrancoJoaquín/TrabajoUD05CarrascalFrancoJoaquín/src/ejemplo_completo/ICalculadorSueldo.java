package ejemplo_completo;

public interface ICalculadorSueldo {
	
	double calcularSueldoUnitario(double porcentajeInterior);

}
