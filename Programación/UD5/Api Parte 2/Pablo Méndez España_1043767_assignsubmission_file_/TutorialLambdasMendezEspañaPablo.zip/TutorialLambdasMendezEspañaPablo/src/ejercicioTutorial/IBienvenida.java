package ejercicioTutorial;

@FunctionalInterface
public interface IBienvenida {

	public void mostrarBienvenida(String mensaje);
	
}
