package ejercicio06;

public class Generadora {

}
