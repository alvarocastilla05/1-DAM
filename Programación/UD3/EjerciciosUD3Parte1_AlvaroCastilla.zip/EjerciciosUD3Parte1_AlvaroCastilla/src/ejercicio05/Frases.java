package ejercicio05;

public class Frases {
	
	

	public void mostrarFrases (String texto, int num) {
		for (int i = 0; i <num; i++) {
			System.out.println((i+1)+". "+texto);
		}
	}
	
	
	
	
	

}
